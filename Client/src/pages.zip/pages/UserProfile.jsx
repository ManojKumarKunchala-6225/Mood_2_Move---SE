import React from "react";
import Navbar from "./Navbar";
import { useNavigate } from "react-router-dom";

const UserProfile = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    // Remove user data from localStorage
    localStorage.removeItem("user");

    // Redirect to homepage
    navigate("/");

    // Optional: reload to refresh navbar icon immediately
    window.location.reload();
  };

  // Retrieve user data (if available)
  const user = JSON.parse(localStorage.getItem("user"));

  return (
    <div
      className="min-h-screen bg-cover bg-center flex items-center justify-center p-4"
      style={{
        backgroundImage: "url('background.jpg')",
      }}
    >
      <Navbar />
      <div className="bg-white bg-opacity-90 rounded-lg shadow-lg w-full max-w-3xl p-6">
        {/* Profile Picture */}
        <div className="flex justify-center mb-6">
          <img
            src="/user.png" // Make sure this image exists in your public folder
            alt="User"
            className="h-32 w-32 rounded-full border-4 border-red-700 object-cover"
          />
        </div>

        {/* User Details */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-lg sm:text-xl mb-6">
            <tbody>
              <tr>
                <td className="py-2 font-semibold text-red-800">Name</td>
                <td className="py-2">{user?.name || "Guest"}</td>
              </tr>
              <tr>
                <td className="py-2 font-semibold text-red-800">Email</td>
                <td className="py-2">{user?.email || "N/A"}</td>
              </tr>
              <tr>
                <td className="py-2 font-semibold text-red-800">Mobile</td>
                <td className="py-2">{user?.mobile || "N/A"}</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <button className="bg-red-600 text-white px-6 py-2 rounded-full hover:bg-red-700 transition">
            Edit
          </button>
          <button className="bg-red-600 text-white px-6 py-2 rounded-full hover:bg-red-700 transition">
            Wishlist
          </button>
          <button className="bg-red-600 text-white px-6 py-2 rounded-full hover:bg-red-700 transition">
            History
          </button>
          {/* Logout Button */}
          <button
            onClick={handleLogout}
            className="bg-gray-600 text-white px-6 py-2 rounded-full hover:bg-gray-700 transition"
          >
            Logout
          </button>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;
