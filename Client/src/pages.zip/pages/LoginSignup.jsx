// src/pages/LoginSignup.jsx
import React, { useRef, useState, useContext } from "react";
import Navbar from "./Navbar";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../AuthContext.jsx";

export default function LoginSignup() {
  const shadeRef = useRef(null);
  const signTextRef = useRef(null);
  const loginTextRef = useRef(null);
  const navigate = useNavigate();

  const { login } = useContext(AuthContext);

  const [signupData, setSignupData] = useState({
    name: "",
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const [loginData, setLoginData] = useState({
    identifier: "", // can be username or email
    password: "",
  });

  const [message, setMessage] = useState("");

  const handleSignUp = () => {
    shadeRef.current.style.left = "45%";
    signTextRef.current.style.display = "none";
    setTimeout(() => {
      loginTextRef.current.style.display = "block";
      loginTextRef.current.style.marginLeft = "59.5%";
    }, 1000);
    setTimeout(() => {
      loginTextRef.current.style.marginLeft = "0";
    }, 1100);
    loginTextRef.current.style.transition = "1s";
    shadeRef.current.style.transition = "1s ease-in-out";
  };

  const handleLogin = () => {
    shadeRef.current.style.left = "-58%";
    loginTextRef.current.style.display = "none";
    setTimeout(() => {
      signTextRef.current.style.display = "block";
      signTextRef.current.style.marginLeft = "0";
    }, 1000);
    setTimeout(() => {
      signTextRef.current.style.marginLeft = "59.5%";
    }, 1100);
    signTextRef.current.style.transition = "1s";
    shadeRef.current.style.transition = "1s ease-in-out";
  };

  const handleSignupSubmit = (e) => {
    e.preventDefault();

    if (signupData.password !== signupData.confirmPassword) {
      setMessage("❌ Passwords do not match");
      return;
    }

    const newUser = {
      name: signupData.name,
      username: signupData.username,
      email: signupData.email,
      password: signupData.password,
    };

    // Save permanently in localStorage
    localStorage.setItem("registeredUser", JSON.stringify(newUser));

    // Log in user immediately after signup
    login(newUser);
    setMessage("✅ Signed up successfully!");
    setTimeout(() => navigate("/"), 1000);
  };

  const handleLoginSubmit = (e) => {
    e.preventDefault();

    const savedUser = JSON.parse(localStorage.getItem("registeredUser"));

    if (
      savedUser &&
      (loginData.identifier === savedUser.username ||
        loginData.identifier === savedUser.email) &&
      loginData.password === savedUser.password
    ) {
      login(savedUser); // set logged-in session
      setMessage("✅ Logged in successfully!");
      setTimeout(() => navigate("/"), 1000);
    } else {
      setMessage("❌ Invalid username/email or password");
    }
  };

  return (
    <div
      className="h-screen w-screen flex items-center justify-center bg-cover bg-center font-sans"
      style={{ backgroundImage: "url('/background.jpg')" }}
    >
      <Navbar />

      <div className="relative w-[900px] h-[600px] rounded-2xl flex items-center justify-center backdrop-blur-md border-2 border-black overflow-hidden shadow-xl bg-transparent">
        <div className="flex relative gap-[10%] w-full h-full">

          {/* Sign Up Form */}
          <form onSubmit={handleSignupSubmit} className="w-1/2 p-8 flex flex-col justify-center gap-4">
            <h1 className="text-3xl font-bold">Sign Up</h1>
            <input
              type="text"
              placeholder="Full Name"
              value={signupData.name}
              onChange={(e) => setSignupData({ ...signupData, name: e.target.value })}
              required
              className="w-[15vw] border-b-2 border-black outline-none bg-transparent placeholder:text-gray-600 focus:border-b-[3px] transition"
            />
            <input
              type="text"
              placeholder="Username"
              value={signupData.username}
              onChange={(e) => setSignupData({ ...signupData, username: e.target.value })}
              required
              className="w-[15vw] border-b-2 border-black outline-none bg-transparent placeholder:text-gray-600 focus:border-b-[3px] transition"
            />
            <input
              type="email"
              placeholder="Email"
              value={signupData.email}
              onChange={(e) => setSignupData({ ...signupData, email: e.target.value })}
              required
              className="w-[15vw] border-b-2 border-black outline-none bg-transparent placeholder:text-gray-600 focus:border-b-[3px] transition"
            />
            <input
              type="password"
              placeholder="Password"
              value={signupData.password}
              onChange={(e) => setSignupData({ ...signupData, password: e.target.value })}
              required
              className="w-[15vw] border-b-2 border-black outline-none bg-transparent placeholder:text-gray-600 focus:border-b-[3px] transition"
            />
            <input
              type="password"
              placeholder="Confirm Password"
              value={signupData.confirmPassword}
              onChange={(e) => setSignupData({ ...signupData, confirmPassword: e.target.value })}
              required
              className="w-[15vw] border-b-2 border-black outline-none bg-transparent placeholder:text-gray-600 focus:border-b-[3px] transition"
            />
            <input
              type="submit"
              value="Sign Up"
              className="border border-black w-[8vw] py-[0.5vw] font-bold text-[1.2vw] rounded-lg mt-[2vw] hover:cursor-pointer active:scale-90 transition"
            />
          </form>

          {/* Login Form */}
          <form onSubmit={handleLoginSubmit} className="w-1/2 p-8 flex flex-col justify-center gap-4">
            <h1 className="text-3xl font-bold">Login</h1>
            <input
              type="text"
              placeholder="Username or Email"
              value={loginData.identifier}
              onChange={(e) => setLoginData({ ...loginData, identifier: e.target.value })}
              required
              className="w-[15vw] border-b-2 border-black outline-none bg-transparent placeholder:text-gray-600 focus:border-b-[3px] transition"
            />
            <input
              type="password"
              placeholder="Password"
              value={loginData.password}
              onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
              required
              className="w-[15vw] border-b-2 border-black outline-none bg-transparent placeholder:text-gray-600 focus:border-b-[3px] transition"
            />
            <input
              type="submit"
              value="Login"
              className="border border-black w-[8vw] py-[0.5vw] font-bold text-[1.2vw] rounded-lg mt-[2vw] hover:cursor-pointer active:scale-90 transition"
            />
          </form>

          {/* Shade Panel */}
          <div
            ref={shadeRef}
            className="absolute w-full h-full rounded-[100px] bg-gradient-to-br from-[#d4fc79] to-[#96e6a1] flex flex-row gap-[25%] pl-[10%] pt-[10%] text-center left-[-58%]"
          >
            {/* Login Text */}
            <div ref={loginTextRef} className="hidden text-[blueviolet] mt-[5em]">
              <p className="text-[2.8vw] font-bold">Welcome Back!</p>
              <p className="font-medium">Already have an account?</p>
              <button
                type="button"
                className="mt-[1vw] h-[2.7vw] w-[7vw] rounded-lg border border-[blueviolet] text-[blueviolet] active:scale-90 transition"
                onClick={handleLogin}
              >
                Login
              </button>
            </div>

            {/* Sign Up Text */}
            <div ref={signTextRef} className="ml-[59.5%] text-[blueviolet] mt-[5em]">
              <p className="text-[2.8vw] font-bold">Hi, Welcome!</p>
              <p className="font-medium">Don't have account?</p>
              <button
                type="button"
                className="mt-[1vw] h-[2.7vw] w-[7vw] rounded-lg border border-[blueviolet] text-[blueviolet] active:scale-90 transition"
                onClick={handleSignUp}
              >
                Sign Up
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Feedback message */}
      {message && (
        <p className="absolute bottom-4 text-center text-lg font-medium text-white bg-black bg-opacity-60 px-4 py-2 rounded-lg">
          {message}
        </p>
      )}
    </div>
  );
}
