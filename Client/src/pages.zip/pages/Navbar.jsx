// src/components/Navbar.jsx
import React, { useEffect, useState } from "react";
import { FaUser, FaSignInAlt } from "react-icons/fa";
import { useNavigate } from "react-router-dom";

export default function Navbar() {
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    // Load from localStorage on mount
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      setIsLoggedIn(true);
      setUser(JSON.parse(storedUser));
    }

    // Listen for login/signup changes from LoginSignup.jsx
    const handleStorageChange = () => {
      const updatedUser = localStorage.getItem("user");
      if (updatedUser) {
        setIsLoggedIn(true);
        setUser(JSON.parse(updatedUser));
      } else {
        setIsLoggedIn(false);
        setUser(null);
      }
    };

    window.addEventListener("storage", handleStorageChange);
    return () => window.removeEventListener("storage", handleStorageChange);
  }, []);
  return (
    <header className="fixed top-0 left-0 right-0 z-50">
      <nav className="flex items-center justify-between p-2 mx-auto max-w-screen transition-colors duration-500 bg-white/10 backdrop-blur-md hover:bg-white/20">
        
        {/* Logo */}
        <div
          className="flex items-center gap-3 cursor-pointer"
          onClick={() => navigate("/")}
        >
          <img
            src="/logo.png"
            alt="Mood2Move Logo"
            className="w-12 h-12 rounded-full"
            onError={(e) => {
              e.currentTarget.src =
                "https://placehold.co/50x50/FFFFFF/000000?text=M2M";
            }}
          />
          <span className="font-bold text-2xl tracking-wider">Mood2Move</span>
        </div>

        {/* Links */}
        <div className="hidden md:flex items-center gap-6">
          <a href="/" className="nav-link">Home</a>
          <a href="./About" className="nav-link">About</a>
          <a href="./Contact" className="nav-link">Contact</a>
          <a href="./BlogPage" className="nav-link">Blog</a>
        </div>

        {/* Auth Section */}
        <div className="flex justify-end gap-3">
          {!isLoggedIn ? (
            <FaSignInAlt
              className="text-white/80 hover:text-cyan-400 cursor-pointer text-xl"
              onClick={() => navigate("/LoginSignup")}
              title="Login / Sign Up"
            />
          ) : (
            <div className="relative group">
              <FaUser
                className="text-white/80 hover:text-cyan-400 cursor-pointer text-xl"
                onClick={() => navigate("/UserProfile")}
                title={user?.name || "User Profile"}
              />
            </div>
          )}
        </div>
      </nav>
    </header>
  );
}
