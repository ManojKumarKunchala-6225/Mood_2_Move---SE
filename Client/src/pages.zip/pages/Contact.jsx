import React, { useState } from "react";
import Navbar from "./Navbar";
const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    setSubmitted(true);
  };

  const handleClose = () => {
    setFormData({ name: "", email: "", message: "" });
    setSubmitted(false);
  };

  return (
    <>
      <Navbar/>

      {/* Contact Form Section */}
      <div
        className="min-h-screen flex items-center justify-center bg-cover bg-center p-4"
        style={{
          backgroundImage: 'url("background.jpg")',
        }}
      >
        <div className="bg-lightgreen bg-opacity-95 p-6 md:p-10 rounded-2xl shadow-lg w-full max-w-2xl relative text-left">
          <h2 className="text-center text-3xl font-bold text-teal-900 mt-4 mb-6">
            Contact Us
          </h2>

          <img
            className="h-72 w-[30em] rounded-lg mx-auto mb-6 object-cover"
            src="ContactUs.png"
            alt="Contact"
          />

          <button
            className="absolute top-4 right-6 text-gray-700 text-2xl hover:text-black"
            onClick={handleClose}
            aria-label="Close form"
          >
            &times;
          </button>

          {!submitted ? (
            <form
              onSubmit={handleSubmit}
              className="flex flex-col gap-6 items-center w-full"
            >
              <input
                type="text"
                name="name"
                placeholder="Your Name"
                value={formData.name}
                onChange={handleChange}
                required
                className="p-3 border border-gray-300 rounded-lg w-full max-w-md"
              />
              <input
                type="email"
                name="email"
                placeholder="Your Email"
                value={formData.email}
                onChange={handleChange}
                required
                className="p-3 border border-gray-300 rounded-lg w-full max-w-md"
              />
              <textarea
                name="message"
                placeholder="Your Message"
                value={formData.message}
                onChange={handleChange}
                required
                className="p-3 border border-gray-300 rounded-lg w-full max-w-md min-h-[100px] resize-y"
              />
              <button
                type="submit"
                className="bg-teal-700 hover:bg-teal-900 text-white py-3 px-6 rounded-lg text-base self-center"
              >
                Send Message
              </button>
            </form>
          ) : (
            <p className="text-center text-lg text-gray-700">
              Thank you for reaching out! We'll get back to you soon.
            </p>
          )}
        </div>
      </div>
    </>
  );
};

export default Contact;
