import React, { useState } from "react";
export default function TouristPlacesSelector() {
  const [selectedOptions, setSelectedOptions] = useState({
    mood: [],
    people: [],
    location: [],
  });

  const handleCheckboxChange = (category, value) => {
    setSelectedOptions((prev) => {
      const currentValues = prev[category];
      return {
        ...prev,
        [category]: currentValues.includes(value)
          ? currentValues.filter((v) => v !== value)
          : [...currentValues, value],
      };
    });
  };

  const handleSearch = () => {
    // In a real app, you would use this data to fetch results
    console.log("Searching with preferences:", selectedOptions);
    alert(JSON.stringify(selectedOptions, null, 2));
  };

  // A reusable Checkbox component to keep the code clean
  const Checkbox = ({ category, value, color, children }) => (
    <label className={`flex items-center space-x-2 bg-${color}-50 p-3 rounded-lg hover:bg-${color}-100 cursor-pointer transform hover:scale-105 transition`}>
      <input
        type="checkbox"
        value={value}
        checked={selectedOptions[category].includes(value)}
        onChange={() => handleCheckboxChange(category, value)}
        className={`w-5 h-5 text-${color}-600 rounded focus:ring-${color}-500`}
      />
      <span>{children}</span>
    </label>
  );

  return (
    <>
      {/* Custom CSS for animations from your HTML file */}
      <style>{`
        @keyframes fadeInUp {
          0% { opacity: 0; transform: translateY(20px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        .fade-in-up {
          animation: fadeInUp 0.6s ease forwards;
        }
        @keyframes pulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.1); }
        }
        .pulse-effect:hover {
          animation: pulse 0.8s infinite;
        }
        @keyframes spin-slow {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        .animate-spin-slow {
            animation: spin-slow 3s linear infinite;
        }
      `}</style>

      <div className="min-h-screen flex items-center justify-center p-6" style={{ backgroundImage: "url('/background.jpg')" }} >
        <div className="bg-white shadow-2xl rounded-2xl p-8 w-full max-w-2xl fade-in-up mt-11">
          <h1 className="text-3xl font-bold text-center text-blue-700 mb-6 animate-bounce">
            Choose Your Tourist Preferences
          </h1>

          {/* Mood Based Section */}
          <section className="mb-6">
            <h2 className="text-xl font-semibold text-gray-700 mb-3 flex items-center gap-2">
              <svg className="w-6 h-6 text-blue-500 animate-spin-slow" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 4a8 8 0 00-8 8 8.01 8.01 0 004.53 7.19l-.53 2.31a1 1 0 001.52 1.05L12 20.5l2.48 1.94a1 1 0 001.52-1.05l-.53-2.31A8.01 8.01 0 0020 12a8 8 0 00-8-8z" />
              </svg>
              Mood Based
            </h2>
            <div className="grid grid-cols-2 gap-4">
              <Checkbox category="mood" value="Peace / Relax" color="blue">Peace / Relax</Checkbox>
              <Checkbox category="mood" value="Adventerous / Fun" color="blue">Adventerous / Fun</Checkbox>
              <Checkbox category="mood" value="Spiritual / Devotional" color="blue">Spiritual / Devotional</Checkbox>
              <Checkbox category="mood" value="Romantic" color="blue">Romantic</Checkbox>

              {/* Center last mood */}
              <div className="col-span-2 flex justify-center">
                <Checkbox category="mood" value="Social / Festive" color="blue">Social / Festive</Checkbox>
              </div>
            </div>
          </section>
          {/* People Based Section */}
          <section className="mb-6 fade-in-up" style={{ animationDelay: '0.2s' }}>
            <h2 className="text-xl font-semibold text-gray-700 mb-3 flex items-center gap-2">
              <svg className="w-6 h-6 text-green-500" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 12c2.21 0 4-1.79 4-4S14.21 4 12 4 8 5.79 8 8s1.79 4 4 4zm6 2h-1.26A8.963 8.963 0 0012 13c-1.78 0-3.43.52-4.74 1.4H6a6 6 0 00-6 6 1 1 0 001 1h22a1 1 0 001-1 6 6 0 00-6-6z" />
              </svg>
              People Based
            </h2>
            <div className="grid grid-cols-2 gap-4">
              <Checkbox category="people" value="Solo" color="green">Solo</Checkbox>
              <Checkbox category="people" value="Family" color="green">Family</Checkbox>
              <Checkbox category="people" value="Couple" color="green">Couple</Checkbox>
              <Checkbox category="people" value="Friends" color="green">Friends</Checkbox>
            </div>
          </section>

          {/* Location */}
          <section className="mb-6 fade-in-up" style={{ animationDelay: '0.4s' }}>
            <h2 className="text-xl font-semibold text-gray-700 mb-3 flex items-center gap-2">
              <svg className="w-6 h-6 text-yellow-500" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87L18.18 22 12 18.8 5.82 22 7 14.14l-5-4.87 6.91-1.01L12 2z" />
              </svg>
              Location
            </h2>
            <div className="grid grid-cols-2 gap-4">
              <Checkbox category="location" value="North" color="yellow">North</Checkbox>
              <Checkbox category="location" value="South" color="yellow">South</Checkbox>
            </div>
          </section>

          {/* Buttons */}
          <div className="flex justify-center gap-4 mb-6">
            <button className="px-6 py-3 bg-blue-600 text-white rounded-xl shadow-md hover:bg-blue-700 transform hover:scale-110 transition pulse-effect">
              Most Visited
            </button>
            <button className="px-6 py-3 bg-pink-500 text-white rounded-xl shadow-md hover:bg-pink-600 transform hover:scale-110 transition pulse-effect">
              Famous in India
            </button>
          </div>

          {/* Search Button */}
          <div className="text-center">
            <button 
              onClick={handleSearch}
              className="px-8 py-3 bg-gradient-to-r from-green-500 to-green-700 text-white text-lg font-semibold rounded-full shadow-lg hover:scale-105 transition duration-300 flex items-center gap-2 mx-auto animate-bounce"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-4.35-4.35M17 10.5a6.5 6.5 0 11-13 0 6.5 6.5 0 0113 0z" />
              </svg>
              Search Places
            </button>
          </div>
        </div>
      </div>
    </>
  );
}