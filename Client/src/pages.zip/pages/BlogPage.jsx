import React from 'react';
import Navbar from "./Navbar";
//== Component: Header (from your home.jsx) ==//
// This is the main navigation bar for the website. It's sticky to the top of the page.
const Header = () => (
  <Navbar/>
);

//== Component: Individual Blog Post ==//
// This component renders the main article, including the text and image carousel.
const BlogPost = ({ image, title, excerpt, carouselImages }) => (
  <article>
    {/* Main Blog Post Section */}
    <div className="flex flex-wrap justify-center">
      <div className="w-full md:w-10/12 lg:w-9/12 mt-6 md:mt-0">
        <div className="blog_post">
          {/* Main image for the blog post */}
          <img src={image} alt={title} className="w-full rounded-lg shadow-md" />
          <div className="blog_details pt-8">
            <h1 className="font-playfair text-3xl text-black font-bold">{title}</h1>
            {/* 'dangerouslySetInnerHTML' is used to render HTML content (e.g., <br/> tags) from a string */}
            <p className="mt-4 text-lg leading-relaxed" dangerouslySetInnerHTML={{ __html: excerpt }}></p>
          </div>
        </div>
      </div>
    </div>

    {/* "My Experience" Section with Image Carousel */}
    <div className="myexperience mt-16">
      <h1 className="font-playfair text-3xl text-heading-color font-bold mb-8 text-center">My experience at Auroville was...</h1>
      <div className="flex flex-wrap -mx-4 items-center">
        {/* Bootstrap Carousel for images */}
        <div className="w-full lg:w-1/2 px-4 mb-6 lg:mb-0">
          <div id="placeCarousel" className="carousel slide shadow-lg rounded-lg overflow-hidden" data-bs-ride="carousel">
            {/* Carousel Indicators (the small dots at the bottom) */}
            <div className="carousel-indicators">
              {carouselImages.map((_, index) => (
                <button
                  type="button"
                  data-bs-target="#placeCarousel"
                  data-bs-slide-to={index}
                  className={index === 0 ? 'active' : ''}
                  aria-current={index === 0 ? 'true' : 'false'}
                  aria-label={`Slide ${index + 1}`}
                  key={index}
                ></button>
              ))}
            </div>
            {/* Carousel Inner container for the images */}
            <div className="carousel-inner relative w-full overflow-hidden">
              {carouselImages.map((img, index) => (
                <div className={`carousel-item ${index === 0 ? 'active' : ''} relative float-left w-full`} key={index}>
                  <img src={img} className="block w-full" alt={`Auroville experience ${index + 1}`} />
                </div>
              ))}
            </div>
            {/* Carousel Controls (Previous and Next buttons) */}
            <button className="carousel-control-prev" type="button" data-bs-target="#placeCarousel" data-bs-slide="prev">
              <span className="carousel-control-prev-icon" aria-hidden="true"></span>
              <span className="visually-hidden">Previous</span>
            </button>
            <button className="carousel-control-next" type="button" data-bs-target="#placeCarousel" data-bs-slide="next">
              <span className="carousel-control-next-icon" aria-hidden="true"></span>
              <span className="visually-hidden">Next</span>
            </button>
          </div>
        </div>
        {/* Experience Text, displayed next to the carousel on larger screens */}
        <div className="w-full lg:w-1/2 px-4">
  <div id="experience" className="text-white text-lg leading-relaxed">
    Visiting Auroville was a truly soul-refreshing experience. As I entered the township, I was immediately struck by the peaceful atmosphere and the lush greenery that surrounded me. The Matrimandir stood tall and majestic — its golden sphere glistening in the sunlight, symbolizing unity and inner peace. I spent time meditating in the quiet zone, and it felt like the world had paused around me.<br/><br/>
    The people I met were from diverse cultures, yet everyone was so welcoming and kind. I enjoyed a delicious organic meal at a local café, made entirely from ingredients grown in Auroville itself. Walking through the community spaces, art galleries, and eco-friendly workshops gave me a deep appreciation for sustainable living and harmony. <br/><br/>
    The slow, thoughtful pace of life there reminded me of the importance of mindfulness and living with intention. Auroville isn’t just a place — it’s an experience that stays with you long after you leave.
  </div>
</div>
      </div>
    </div>
  </article>
);


//== Component: Main Blog Section Container ==//
// This component defines the main content of the blog page and passes it to the BlogPost component.
const BlogSection = () => {
    // Data for the main blog post, extracted from the HTML file.
    const mainPost = {
  title: "Auroville In Brief",
  image: "mainimg.jpeg",
  excerpt: `<div style="color: white;">
    Auroville is a universal township in the making for a population of up to 50,000 people from around the world. The concept of Auroville - an ideal township devoted to an experiment in human unity - came to the Mother as early as the 1930s.<br/><br/>
    In the mid-1960s the concept was developed and put before the Govt. of India, who gave their backing and took it to the General Assembly of UNESCO.<br/><br/>
    In 1966 UNESCO passed a unanimous resolution commending Auroville as a project of international importance for the future of humanity, thereby giving their full encouragement.
  </div>`,
  carouselImages: [
    "auroville3.jpg", "auroville4.jpg", "auroville5.jpg", "auroville6.jpg", "auroville7.jpg",
    "auroville8.jpg", "auroville9.jpg", "auroville10.jpg", "auroville11.jpg"
  ]
};
    return (
        <section  className="">
            <div className="container mx-auto px-4  backdrop-blur-sm p-8 rounded-lg shadow-lg ">
                <div className="text-center mb-12">
                    <h1 className="text-3xl text-amber-800 underline font-bold">New on the blog</h1>
                    <h2 className="mt-6 text-2xl text-red-800 font-['Lucida_Sans']">
                        "At last a place where one will be able to think only of the future: <span className="text-4xl">Auroville</span> <sub>-The city of dawn-</sub>"
                    </h2>
                </div>
                {/* Renders the BlogPost component with the data defined above */}
                <BlogPost {...mainPost} />
            </div>
        </section>
    );
};


//== Component: Banner ==//
// This is the top introductory section of the page, below the header.
const Banner = () => (
    <section className="relative pt-12">
        <div className="container mx-auto px-4">
            <div id="intro" className="flex flex-wrap items-center flex-col lg:flex-row bg-cover bg-center bg-no-repeat backdrop-blur-sm p-8 rounded-lg shadow-lg" style={{ }} >
                {/* The main banner image */}
                <div id="img" className="w-full lg:w-1/2 min-h-[60vh] bg-cover bg-center rounded-lg shadow-lg" style={{ backgroundImage: "url('auroville.jpg')" }}>
                </div>
                {/* The introductory text next to the banner image */}
                <div id="info" className="w-full lg:w-1/2 py-12 lg:py-20 pl-0 lg:pl-12">
                    <h2 className="font-playfair text-4xl text-heading-color font-bold leading-tight">Fill your travels with colour, culture & creativity.</h2>
                    <p className="mt-5 text-white text-lg leading-relaxed">
                        We are team of Move2Move creators, a travel enthusiast passionate about uncovering hidden gems and cultural treasures across India and beyond.
                        <br/><br/>
                        We love exploring new places through local traditions, food, festivals, and scenic beauty. Discover my thoughtfully crafted itineraries, insider travel tips, and inspiring guides to help you plan meaningful journeys across India.
                    </p>
                </div>
            </div>
        <div id="gap" className="py-8 mt-12 text-center backdrop-blur-sm p-8 rounded-lg shadow-l">
        <p className="text-xl md:text-2xl font-medium">
            So grab a cup of chai ☕, browse through our posts, and let your wanderlust take flight.
        </p>
        <span className="text-3xl font-light mt-2 block">
            Adventure begins here!
        </span>
        </div>
        </div>
        {/* A separator section with a call to action */}
    </section>
);

//== Component: Footer ==//
{/*const Footer = () => (
  <footer className="bg-dark-bg/90 backdrop-blur-sm text-text-color">
    <div className="container mx-auto px-4">
      <div className="footer-top py-20 md:py-28">
        <div className="flex flex-wrap -mx-4">
          <div className="w-full sm:w-1/2 lg:w-3/12 px-4 mb-8">
            <h6 className="text-white font-playfair font-semibold text-lg mb-6">About Crafted</h6>
            <p className="text-sm">The world has become so fast paced that people don’t want to stand by reading a page of information.</p>
          </div>
          <div className="w-full sm:w-1/2 lg:w-3/12 px-4 mb-8">
            <h6 className="text-white font-playfair font-semibold text-lg mb-6">Navigation Links</h6>
            <div className="flex text-sm">
              <ul className="space-y-3 mr-10">
                <li><a href="#" className="hover:text-white">Home</a></li>
                <li><a href="#" className="hover:text-white">Services</a></li>
                <li><a href="#" className="hover:text-white">Project</a></li>
              </ul>
              <ul className="space-y-3">
                <li><a href="#" className="hover:text-white">Team Members</a></li>
                <li><a href="#" className="hover:text-white">Blog</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
              </ul>
            </div>
          </div>
          <div className="w-full sm:w-1/2 lg:w-3/12 px-4 mb-8">
            <h6 className="text-white font-playfair font-semibold text-lg mb-6">Newsletter</h6>
            <p className="text-sm mb-4">For business professionals caught between high OEM price and mediocre print.</p>
            <form>
              <div className="flex">
                <input className="bg-transparent border border-[#333] border-r-0 text-white py-2 px-3 w-full text-sm focus:bg-[#222] focus:outline-none" type="email" placeholder="Enter Email" />
                <button className="bg-custom-orange text-white px-4 hover:opacity-80 transition-opacity">
                  <i className="fa fa-paper-plane"></i>
                </button>
              </div>
            </form>
          </div>
          <div className="w-full sm:w-1/2 lg:w-3/12 px-4 mb-8">
            <h6 className="text-white font-playfair font-semibold text-lg mb-6">Instafeed</h6>
            <ul className="flex flex-wrap -m-1">
              {Array.from({ length: 8 }, (_, i) => i + 1).map(i => (
                <li key={i} className="w-1/4 p-1"><img src={`/img/instagram/i${i}.jpg`} alt={`instagram feed ${i}`} /></li>
              ))}
            </ul>
          </div>
        </div>
      </div>
      <div className="footer-bottom border-t border-[#333] py-7">
        <div className="flex flex-wrap justify-between items-center">
            <p className="text-sm text-center md:text-left w-full md:w-auto mb-4 md:mb-0">
                Copyright &copy;{new Date().getFullYear()} All rights reserved | This template is made with <i className="fa fa-heart-o text-custom-orange"></i> by <a href="https://colorlib.com" target="_blank" rel="noreferrer" className="text-custom-orange font-medium">Colorlib</a>
            </p>
            <div className="flex space-x-6 text-gray-400 justify-center w-full md:w-auto">
                <a href="#" className="hover:text-custom-orange"><i className="fa fa-facebook"></i></a>
                <a href="#" className="hover:text-custom-orange"><i className="fa fa-twitter"></i></a>
                <a href="#" className="hover:text-custom-orange"><i className="fa fa-dribbble"></i></a>
                <a href="#" className="hover:text-custom-orange"><i className="fa fa-behance"></i></a>
            </div>
        </div>
      </div>
    </div>
  </footer>
);*/}


//== Main App Component (Export this) ==//
// This is the root component for this page. It assembles all the other components.
export default function BlogPage() {
  return (
    <div
      className="font-roboto text-text-color text-sm leading-7 min-h-screen"
      style={{
        backgroundImage: "url('/background.jpg')",
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed'
      }}
    >
        <Header />
        <div 
            className="text-center py-4 bg-cover bg-center shadow-md" 
            style={{}}
        >
            <h1 
                className="text-2xl font-semibold text-white tracking-wider"
                style={{ textShadow: '1px 1px 3px rgba(0,0,0,0.5)' }}
            >
                Welcome to Our New Blog - Auroville
            </h1>
        </div>
        <main>
            <Banner />
            <BlogSection />
        </main>
        {/*<Footer />*/}
    </div>
  );
}
