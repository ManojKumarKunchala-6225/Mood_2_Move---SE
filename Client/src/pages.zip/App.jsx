// src/App.jsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import LoginSignup from './pages/LoginSignup';
import Contact from './pages/Contact';
import BlogPage from './pages/BlogPage';
import About from './pages/About';
import Explore from './pages/Explore';
import UserProfile from './pages/UserProfile';
import Navbar from './pages/Navbar';
import { AuthProvider } from "./AuthContext.jsx"; // ✅ Updated
import './App.css';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Navbar /> {/* ✅ Moved here so it shows on every page */}
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/loginsignup" element={<LoginSignup />} />
          <Route path="/contact" element={<Contact />} />     
          <Route path="/blogpage" element={<BlogPage />} />
          <Route path="/about" element={<About/>}/>
          <Route path="/explore" element={<Explore/>}/>
          <Route path="/userprofile" element={<UserProfile/>}/>
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
